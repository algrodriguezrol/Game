vga
===

A very simple VGA interface. The target platform is the [TerasIC DE0-Nano
board](http://www.terasic.com.tw/cgi-bin/page/archive.pl?No=593), but
should work with any FPGA board withe enough GPIO ports and fast enough
clock.
